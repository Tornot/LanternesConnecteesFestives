

# Import needed modules from osc4py3
from osc4py3.as_eventloop import *
from osc4py3 import oscmethod as osm
import paho.mqtt.publish as publish

sound_bass = 0
sound_snare = 0

def send_in_mqtt(topic, value):
    publish.single(topic, value, hostname="10.42.0.1")
    print("Message sent in MQTT")


def send_bass():
    send_in_mqtt("paho/test/single/bass", sound_bass)


def send_snare():
    send_in_mqtt("paho/test/single/snare", sound_snare)


def handlerfunction2(address, s):
    global sound_bass  # To write in the global variable
    # Will receive message address, and message data flattened in s, x, y
    print(address)
    bass = s*127
    sound_bass = (round(bass))
    print("bass : ", sound_bass)
    send_bass()
    pass

# Start the system.
osc_startup()

# Make server channels to receive packets.
osc_udp_server("192.100.0.2", 9001, "aservername")

# Too, but request the message address pattern before in argscheme
osc_method("/test*", handlerfunction2, argscheme=osm.OSCARG_ADDRESS + osm.OSCARG_DATAUNPACK)

# Periodically call osc4py3 processing method in your event loop.
finished = False
while not finished:

    osc_process()


# Properly close the system.
osc_terminate()

